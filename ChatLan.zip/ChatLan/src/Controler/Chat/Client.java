package Controler.Chat;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;

public class Client {

    @FXML
    private TextArea textSmg;

    String textAreaMsg;

    @FXML
    private void sendMsg(MouseEvent event){
        textAreaMsg = textSmg.getText();
        System.out.println(textAreaMsg);
    }

    
}
